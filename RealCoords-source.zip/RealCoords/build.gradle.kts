plugins {
    java
    id("com.gradleup.shadow") version "8.3.5"
}

group = "dev.realcoords"
version = "1.0.0"

val geyserVersion: String by project
val javaVersion: String by project

repositories {
    mavenCentral()
    maven("https://repo.opensource.geysermc.org/content/repositories/releases/")
    maven("https://repo.opensource.geysermc.org/content/repositories/snapshots/")
    maven("https://repo.opensource.geysermc.org/repository/maven-public/")
}

dependencies {
    // Geyser 與 Cloudburst Protocol / Netty / NBT 由 Geyser 在執行時提供
    compileOnly("org.geysermc.geyser:api:$geyserVersion")
    compileOnly("org.geysermc.geyser:core:$geyserVersion")
    implementation("org.yaml:snakeyaml:2.2")
}

tasks.withType<JavaCompile> {
    options.encoding = "UTF-8"
    options.release.set(javaVersion.toInt())
}

tasks.shadowJar {
    archiveClassifier.set("")
    relocate("org.yaml.snakeyaml", "dev.realcoords.libs.snakeyaml")
}

tasks.build { dependsOn(tasks.shadowJar) }
